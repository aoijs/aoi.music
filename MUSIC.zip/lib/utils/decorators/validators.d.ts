export declare function decorateMethod(func: (method: any, ...args: any[]) => any): (_0: any, _1: any, descriptor: PropertyDescriptor) => PropertyDescriptor;
export declare namespace Queue {
    function validatePlayer(): (...args: any[]) => any;
}
