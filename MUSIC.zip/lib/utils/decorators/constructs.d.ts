export declare function decorateConstructor(func: (target: any, args: any[]) => any): (target: any) => any;
export declare function constructManager(): (target: any) => any;
export declare function constructCache(): (target: any) => any;
export declare function constructSoundcloud(): (target: any) => any;
export declare function constructTrack(): (target: any) => any;
