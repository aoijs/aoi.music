import { TwitchOptions } from "../typings";
declare class TwitchProvider {
    options: TwitchOptions;
}
export default TwitchProvider;
