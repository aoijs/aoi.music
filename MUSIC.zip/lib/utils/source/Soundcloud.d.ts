import { SoundcloudOptions } from "../typings";
declare class SoundcloudProvider {
    options: SoundcloudOptions;
    constructor(config: SoundcloudOptions);
}
export default SoundcloudProvider;
