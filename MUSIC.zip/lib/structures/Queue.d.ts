import Player from "./Player";
import Track from "./Track";
declare class PlayerQueue {
    player: Player;
    list: Track[];
    current: any;
    previous: any;
    setPlayer(player: Player): void;
    setCurrent(track: Track): void;
}
export default PlayerQueue;
