# music
Addition of the Music properties and foundation for aoi.js
