import { TwitchOptions } from "../typings";

class TwitchProvider {
    public options: TwitchOptions = {clientId: /*have fun*/"kimne78kx3ncx6brgo4mv6wki5h1ko"}
}

export default TwitchProvider;