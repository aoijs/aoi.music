import { SourceProviders } from "../constants";
import { SoundcloudOptions } from "../typings";

class SoundcloudProvider {
    public options: SoundcloudOptions = {clientId: ""}
    constructor(config: SoundcloudOptions) {
        
    }
}
// search thingy, bu for souncloud
//i have a premade one? which gets the search , info and stream
// this, you can get yours

export default SoundcloudProvider;